For the following subjects, the timing of stimulation used a random-weight classifier, rather than a patient-specific weighted classifier.

R1275D
R1292E
R1304N
R1308T
R1315T
R1317D
R1320D
R1321M
R1328E
R1330D
R1334T
R1339D
R1341T
R1345D
R1351M
